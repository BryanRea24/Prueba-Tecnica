<?php
$host = "localhost";       // usualmente localhost
$user = "root";            // tu usuario de MySQL
$password = "";            // tu contraseña de MySQL
$dbname = "prueba_tecnica"; // tu base de datos

// Crear conexión
$conexion = new mysqli($host, $user, $password, $dbname);

// Verificar conexión
if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
} 
echo "¡Conexión exitosa a la base de datos!";
?>
