<?php
session_start();
include 'conexion.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $conexion->real_escape_string($_POST['usuario']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM vw_usuarios WHERE usuario = '$usuario' AND visible = 1";
    $result = $conexion->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['contrasenia'])) {
            $_SESSION['nombre_completo'] = $row['nombre_completo'];
            header('Location: dashboard.php');
            exit;
        } else {
            $error = "Contraseña incorrecta.";
        }
    } else {
        $error = "Usuario no encontrado o inactivo.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login | Gobierno del Estado</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      background: linear-gradient(135deg, #003366, #004b87);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .card-login {
      background: #fff;
      border-radius: 15px;
      box-shadow: 0 0 20px rgba(0,0,0,0.2);
      overflow: hidden;
      display: flex;
      width: 900px;
      max-width: 95%;
    }
    .card-login .left {
      background: #004b87;
      color: #fff;
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      padding: 40px;
    }
    .card-login .left img {
      max-width: 200px;
      margin-bottom: 20px;
    }
    .card-login .right {
      flex: 1;
      padding: 50px 40px;
    }
    .form-control {
      border-radius: 30px;
    }
    .btn-primary {
      border-radius: 30px;
    }
    h2 {
      font-weight: 700;
    }
  </style>
</head>
<body>
  <div class="card-login">
    <!-- Lado izquierdo -->
    <div class="left">
      <img src="img/logo_gob.png" alt="Gobierno del Estado">
      <h2 class="text-center">Gobierno del Estado</h2>
      <p class="text-center">Accede al sistema de gestión interna</p>
    </div>

    <!-- Lado derecho -->
    <div class="right">
      <h3 class="mb-4 text-center">Iniciar Sesión</h3>

      <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>

      <form method="POST" action="">
        <div class="mb-3">
          <label for="usuario" class="form-label">Usuario</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-user"></i></span>
            <input type="text" class="form-control" id="usuario" name="usuario" required autocomplete="username" />
          </div>
        </div>
        <div class="mb-4">
          <label for="password" class="form-label">Contraseña</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" class="form-control" id="password" name="password" required autocomplete="current-password" />
          </div>
        </div>
        <button type="submit" class="btn btn-primary w-100">
          <i class="fas fa-sign-in-alt"></i> Ingresar
        </button>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
