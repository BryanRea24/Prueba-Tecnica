-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 14-07-2025 a las 20:38:54
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `prueba_tecnica`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfiles`
--

CREATE TABLE `perfiles` (
  `id_perfil` int(11) NOT NULL,
  `dsc_perfil` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `perfiles`
--

INSERT INTO `perfiles` (`id_perfil`, `dsc_perfil`) VALUES
(1, 'Administrador'),
(2, 'RH'),
(3, 'DG');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `id_perfil` int(11) DEFAULT NULL,
  `usuario` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `primer_apellido` varchar(50) NOT NULL,
  `contrasenia` varchar(255) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `id_perfil`, `usuario`, `nombre`, `primer_apellido`, `contrasenia`, `visible`) VALUES
(1, 1, 'AGUSTIN', 'AGUSTIN', 'GONZÁLEZ', '$2y$10$65mxfRN.ReO087sJ8C4gTOuYT/DAX2uma8UUh5h0knWIPNo1/KEbm', 1),
(2, 2, 'eaburto', 'EDUARDO', 'GONZÁLEZ', '$2y$10$FHXckDxtu155daI7hBW1Wu.prIGswGhRIXmuk9AKBFR8fHfo1lz9K', 1),
(3, 3, 'jlrendonb', 'JOSÉ LUIS', 'GONZÁLEZ', '$2y$10$VqkjC.9iUnm4UhVjEo5p/O/JN3EHaPmgyNLZ8F3gT2Jmp8FSmLs5K', 1),
(4, 2, 'salvador.garcia', 'SALVADOR', 'GRANADOS', '$2y$10$ejxWmr9HTFwHhgcBdBBkS.MBiifLEXxBFNxJjnZerlixryVAMFN1e', 1),
(5, 1, 'jglezlezo', 'JOSETTE', 'GUTIÉRREZ', '$2y$10$yoVbQYSOFv/axc3iVuHhPOJIz1iYyxDve0HA483Lc6LQ0w.USFxXC', 1),
(6, 2, 'zulema.lira', 'ZULEMA', 'HERNÁNDEZ', '$2y$10$5cvSyAOKGuWRaEIDys/e0eklWXPTD9GmrkwMs8dAZeUqxYXqYBURO', 1),
(7, 3, 'mcamila', 'MARIANA CAMILA', 'HERNÁNDEZ', '$2y$10$lovrS8c6JvMOQGAJAMTuTuwV4mkFuKsjBd1owLhAmbEZjsBRESBnq', 1),
(8, 2, 'agenriquez', 'ANA GUADALUPE', 'HERNÁNDEZ', '$2y$10$EK1eB7L70oh9mJlV/6/VC.TxAYBDbjhYQlqx65/hX0QtQLOxQ1plW', 1),
(9, 1, 'lgrabriel', 'LUIS GABRIEL', 'HERNÁNDEZ', '$2y$10$wnSRBm/e4P75WRO5xhD4w.jDouDhr8SQUTi1JwNQwv8Y7KziSozau', 1),
(10, 2, 'jacostap', 'JUAN ANTONIO', 'HERNÁNDEZ', '$2y$10$mgw0oWneY9QLtR6ix068XuQfUitW8/0fLxwh4gzLh1q38bFl.dKyW', 1),
(11, 3, 'aguilar.jorge', 'JORGE', 'HUETT', '$2y$10$nMqwKZbLM9INHa.iSAMMrONeu8Y3Sw1QS99iCNeVk8h.MnZ2mLoOm', 1),
(12, 2, 'ralfonzo', 'RICARDO DANIEL', 'JASSO', '$2y$10$8xT/MZoaHRHi9GhodrC1me77U.d5bN4uhaUL/G7GJzMIVzXgTscIS', 1),
(13, 1, 'ialvarezp', 'IRAZEMA DEL ROCÍO', 'JIMÉNEZ', '$2y$10$hi96C8eJE8MJb0/ujRKuCOANr2bXopGhMX75SaLf.qUZ2o/0iM/WO', 1),
(14, 2, 'jmazavala', 'JUAN MANUEL', 'JUÁREZ', '$2y$10$G6Tan0EL.rtzMrCVRy351OQsFWlsYFCQiefWgYUUdLHcR6y07BH2C', 1),
(15, 3, 'rantonio', 'ROCÍO', 'LANDÍN', '$2y$10$XELQqo2xZcCzdalyL7O.pO.hHYJL71av1sOkrE3bak771zGQC3eQG', 1),
(16, 2, 'karroyo', 'KAREN MONSERRAT', 'LARA', '$2y$10$WhzuVPj1M0h58ECVs1vNI.ATLqJVLKj1rhZkKDkjLFvnIroNE/MAS', 1),
(17, 1, 'mascencio', 'MARÍA YOSSELÍN', 'LÓPEZ', '$2y$10$Q1RLo4154hbU21An3pve3uIb9b3zyfQIH4ssqj/5Ej0nYCKtS1O7S', 1),
(18, 2, 'dayalasa', 'DAVID', 'LOYA', '$2y$10$lEsk/gNwwlp/Z.cINrAmDOiEtb9Tz4Vn1N0tsQ96KurEPBJvO19dW', 1),
(19, 3, 'aayalaserr', 'ALEJANDRO', 'LUÉVANOS', '$2y$10$4IEItu6BTi8tgVZeF0D0k.zkWNU7mCDch1Dn2NP98bjZL6Prp5Cfu', 1),
(20, 2, 'lebalderas', 'LETICIA', 'LUGO', '$2y$10$qPSJrJbdIktg64qo67sByu81TKtjRVpzaviBsDzARHirXnUJpk2f6', 1),
(21, 1, 'elimdalet', 'ELIM DALET', 'MAGAÑA', '$2y$10$AaRgHJYV8/vFiui8yrWzEeZOpokgMTUTh5T4oFlM4Ua9y9tFUsQYe', 1),
(22, 2, 'sbeltranl', 'SERGIO KARLO', 'MAGDALENO', '$2y$10$GZhqQQ4XZNto0WUL4Zx78.lcmVdNf8DUHlfZOYRqQQZ5Ka35o8jYW', 1),
(23, 3, 'dcabreras', 'DULCE MARÍA TERESITA', 'MARES', '$2y$10$PprhTtyZ55iEUJUIomxnl.Gh2g1nzHZ.9imryYW3.s87aZYL4wJCu', 1),
(24, 2, 'ccampos', 'CLAUDIA LORENA', 'MARTÍNEZ', '$2y$10$Zb9y3T/hoBmGOUXKoAC16OHTrLbCiWURFEBm6RRLd3b9VY/F2zDXi', 1);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vw_usuarios`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vw_usuarios` (
`id_usuario` int(11)
,`id_perfil` int(11)
,`dsc_perfil` varchar(100)
,`nombre_completo` varchar(101)
,`usuario` varchar(50)
,`contrasenia` varchar(255)
,`visible` tinyint(1)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `vw_usuarios`
--
DROP TABLE IF EXISTS `vw_usuarios`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_usuarios`  AS SELECT `u`.`id_usuario` AS `id_usuario`, `p`.`id_perfil` AS `id_perfil`, `p`.`dsc_perfil` AS `dsc_perfil`, concat(`u`.`nombre`,' ',`u`.`primer_apellido`) AS `nombre_completo`, `u`.`usuario` AS `usuario`, `u`.`contrasenia` AS `contrasenia`, `u`.`visible` AS `visible` FROM (`usuarios` `u` join `perfiles` `p` on(`u`.`id_perfil` = `p`.`id_perfil`))  ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  ADD PRIMARY KEY (`id_perfil`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD KEY `id_perfil` (`id_perfil`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_perfil`) REFERENCES `perfiles` (`id_perfil`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
