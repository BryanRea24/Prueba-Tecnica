<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['nombre_completo'])) {
    header('Location: login.php');
    exit;
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "UPDATE usuarios SET visible = 0 WHERE id_usuario = $id";
    $conexion->query($sql);
}

header('Location: usuarios.php');
exit;
?>
