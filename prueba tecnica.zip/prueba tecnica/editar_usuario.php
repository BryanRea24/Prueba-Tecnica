<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['nombre_completo'])) {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

if (!isset($_GET['id'])) {
    header('Location: usuarios.php');
    exit;
}

$id_usuario = intval($_GET['id']);

$sql_perfiles = "SELECT * FROM perfiles";
$res_perfiles = $conexion->query($sql_perfiles);

$sql_usuario = "SELECT * FROM usuarios WHERE id_usuario = $id_usuario AND visible = 1";
$res_usuario = $conexion->query($sql_usuario);

if ($res_usuario->num_rows != 1) {
    header('Location: usuarios.php');
    exit;
}

$usuario_data = $res_usuario->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_perfil = intval($_POST['id_perfil']);
    $usuario = $conexion->real_escape_string($_POST['usuario']);
    $nombre = $conexion->real_escape_string($_POST['nombre']);
    $primer_apellido = $conexion->real_escape_string($_POST['primer_apellido']);
    $password = $_POST['password'];

    // Validar usuario único si cambió
    if ($usuario != $usuario_data['usuario']) {
        $sql_check = "SELECT * FROM usuarios WHERE usuario = '$usuario' AND id_usuario != $id_usuario AND visible = 1";
        $res_check = $conexion->query($sql_check);
        if ($res_check->num_rows > 0) {
            $error = "El usuario ya existe.";
        }
    }

    if (empty($error)) {
        $hash_password = $usuario_data['contrasenia']; // Mantener actual si no se cambia
        if (!empty($password)) {
            $hash_password = password_hash($password, PASSWORD_DEFAULT);
        }

        $sql_update = "UPDATE usuarios SET 
            id_perfil = $id_perfil,
            usuario = '$usuario',
            nombre = '$nombre',
            primer_apellido = '$primer_apellido',
            contrasenia = '$hash_password'
            WHERE id_usuario = $id_usuario";

        if ($conexion->query($sql_update)) {
            $success = "Usuario actualizado correctamente.";
            $usuario_data = $conexion->query($sql_usuario)->fetch_assoc();
        } else {
            $error = "Error al actualizar usuario: " . $conexion->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Editar Usuario</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #f4f6f9;
    }
    .navbar {
      background: #006341;
    }
    .card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    footer {
      background: #006341;
      color: #fff;
      text-align: center;
      padding: 15px 0;
      margin-top: 50px;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand fw-bold" href="dashboard.php">
      <i class="fas fa-building-columns"></i> Gobierno del Estado de Guanajuato
    </a>
    <div class="d-flex">
      <span class="navbar-text text-white me-3">
        <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['nombre_completo']); ?>
      </span>
      <a href="logout.php" class="btn btn-outline-light btn-sm">
        <i class="fas fa-sign-out-alt"></i> Cerrar sesión
      </a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="fas fa-user-edit"></i> Editar Usuario</h2>
    <a href="usuarios.php" class="btn btn-secondary">
      <i class="fas fa-arrow-left"></i> Volver al listado
    </a>
  </div>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
  <?php elseif ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
  <?php endif; ?>

  <div class="card p-4">
    <form method="POST" action="">
      <div class="mb-3">
        <label for="id_perfil" class="form-label">Perfil</label>
        <select id="id_perfil" name="id_perfil" class="form-select" required>
          <?php while ($perfil = $res_perfiles->fetch_assoc()): ?>
            <option value="<?php echo $perfil['id_perfil']; ?>" <?php if ($perfil['id_perfil'] == $usuario_data['id_perfil']) echo 'selected'; ?>>
              <?php echo htmlspecialchars($perfil['dsc_perfil']); ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
      <div class="mb-3">
        <label for="usuario" class="form-label">Usuario</label>
        <input type="text" id="usuario" name="usuario" class="form-control" value="<?php echo htmlspecialchars($usuario_data['usuario']); ?>" required />
      </div>
      <div class="mb-3">
        <label for="nombre" class="form-label">Nombre</label>
        <input type="text" id="nombre" name="nombre" class="form-control" value="<?php echo htmlspecialchars($usuario_data['nombre']); ?>" required />
      </div>
      <div class="mb-3">
        <label for="primer_apellido" class="form-label">Primer Apellido</label>
        <input type="text" id="primer_apellido" name="primer_apellido" class="form-control" value="<?php echo htmlspecialchars($usuario_data['primer_apellido']); ?>" required />
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Nueva Contraseña <span class="text-muted">(dejar vacío para no cambiar)</span></label>
        <input type="password" id="password" name="password" class="form-control" />
      </div>
      <button type="submit" class="btn btn-success">
        <i class="fas fa-save"></i> Actualizar Usuario
      </button>
    </form>
  </div>
</div>

<footer>
  © <?php echo date("Y"); ?> Gobierno del Estado de Guanajuato | Sistema Interno de Usuarios
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
