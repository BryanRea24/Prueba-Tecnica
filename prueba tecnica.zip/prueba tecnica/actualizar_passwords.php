<?php
$conexion = new mysqli("localhost", "root", "", "prueba_tecnica");

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

$sql = "SELECT id_usuario FROM usuarios";
$result = $conexion->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $hash = password_hash('123456', PASSWORD_DEFAULT);
        $id = $row['id_usuario'];
        $update = "UPDATE usuarios SET contrasenia = '$hash' WHERE id_usuario = $id";
        $conexion->query($update);
    }
    echo "Contraseñas actualizadas correctamente.";
} else {
    echo "No se encontraron usuarios para actualizar.";
}

$conexion->close();
?>
