<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['nombre_completo'])) {
    header('Location: login.php');
    exit;
}

$sql = "SELECT * FROM vw_usuarios WHERE visible = 1 ORDER BY id_usuario";
$result = $conexion->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Listado de Usuarios</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #f4f6f9;
    }
    .navbar {
      background: #006341; /* Verde institucional */
    }
    .btn-regresar {
      background: #006341;
      border: none;
    }
    .btn-regresar:hover {
      background: #004d32;
    }
    .card {
      border: none;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    footer {
      background: #006341;
      color: #fff;
      text-align: center;
      padding: 15px 0;
      position: fixed;
      width: 100%;
      bottom: 0;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand fw-bold" href="dashboard.php">
      <i class="fas fa-building-columns"></i> Gobierno del Estado de Guanajuato
    </a>
    <div class="d-flex">
      <span class="navbar-text text-white me-3">
        <i class="fas fa-user-circle"></i> <?php echo htmlspecialchars($_SESSION['nombre_completo']); ?>
      </span>
      <a href="logout.php" class="btn btn-outline-light btn-sm">
        <i class="fas fa-sign-out-alt"></i> Cerrar sesión
      </a>
    </div>
  </div>
</nav>

<div class="container py-4">
  <div class="d-flex justify-content-between mb-3">
    <h2>Listado de Usuarios</h2>
    <a href="dashboard.php" class="btn btn-regresar text-white">
      <i class="fas fa-arrow-left"></i> Menú Principal
    </a>
  </div>

  <div class="mb-3">
    <a href="agregar_usuario.php" class="btn btn-success">
      <i class="fas fa-user-plus"></i> Agregar Nuevo Usuario
    </a>
  </div>

  <div class="card p-4">
    <table class="table table-striped table-hover align-middle">
      <thead class="table-success">
        <tr>
          <th>ID</th>
          <th>Usuario</th>
          <th>Nombre Completo</th>
          <th>Perfil</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
          <?php while ($row = $result->fetch_assoc()): ?>
          <tr>
            <td><?php echo $row['id_usuario']; ?></td>
            <td><?php echo htmlspecialchars($row['usuario']); ?></td>
            <td><?php echo htmlspecialchars($row['nombre_completo']); ?></td>
            <td><?php echo htmlspecialchars($row['dsc_perfil']); ?></td>
            <td>
              <a href="editar_usuario.php?id=<?php echo $row['id_usuario']; ?>" class="btn btn-warning btn-sm">
                <i class="fas fa-edit"></i> Editar
              </a>
              <a href="eliminar_usuario.php?id=<?php echo $row['id_usuario']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('¿Seguro que quieres eliminar este usuario?');">
                <i class="fas fa-trash-alt"></i> Eliminar
              </a>
            </td>
          </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="5" class="text-center">No hay usuarios registrados.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<footer>
  © <?php echo date("Y"); ?> Gobierno del Estado de Guanajuato | Sistema Interno de Usuarios
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
