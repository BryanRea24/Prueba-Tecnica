<?php
session_start();
if (!isset($_SESSION['nombre_completo'])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard | Sistema de Usuarios</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #f4f6f9;
    }
    .navbar {
      background: #006341; /* Verde institucional */
    }
    .card {
      border: none;
      border-radius: 15px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    .card h5 {
      font-weight: 600;
    }
    .logo-gob {
      max-width: 180px;
      margin-bottom: 20px;
    }
    footer {
      background: #006341;
      color: #fff;
      text-align: center;
      padding: 15px 0;
      position: fixed;
      width: 100%;
      bottom: 0;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#">
      <i class="fas fa-building-columns"></i> Gobierno del Estado de Guanajuato
    </a>
    <div class="d-flex align-items-center">
      <span class="navbar-text text-white me-3">
        <i class="fas fa-user-circle"></i> Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre_completo']); ?>
      </span>
      <a href="logout.php" class="btn btn-outline-light btn-sm">
        <i class="fas fa-sign-out-alt"></i> Cerrar sesión
      </a>
    </div>
  </div>
</nav>

<div class="container py-5">
  <div class="text-center mb-4">
    <!-- 🟢 LOGO INSTITUCIONAL -->
    <img src="img/logo_gob.png" alt="Logo Gobierno del Estado" class="logo-gob">
    <h1 class="fw-bold">Panel Principal</h1>
    <p class="text-muted">Bienvenido al sistema de administración de usuarios</p>
  </div>

  <div class="row g-4">
    <div class="col-md-4">
      <div class="card p-4 text-center">
        <i class="fas fa-users fa-3x mb-3 text-success"></i>
        <h5>Gestión de Usuarios</h5>
        <p>Visualiza, crea, edita y elimina registros de usuarios activos en el sistema.</p>
        <a href="usuarios.php" class="btn btn-success w-100">Ir a Usuarios</a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card p-4 text-center">
        <i class="fas fa-shield-alt fa-3x mb-3 text-primary"></i>
        <h5>Seguridad</h5>
        <p>Administra contraseñas, privilegios y perfiles de acceso de forma segura.</p>
        <a href="#" class="btn btn-primary w-100 disabled">En mantenimiento</a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card p-4 text-center">
        <i class="fas fa-chart-line fa-3x mb-3 text-info"></i>
        <h5>Reportes</h5>
        <p>Consulta métricas y reportes clave para la toma de decisiones internas.</p>
        <a href="#" class="btn btn-info w-100 disabled">En Mantenimiento</a>
      </div>
    </div>
  </div>
</div>

<footer>
  © <?php echo date("Y"); ?> Gobierno del Estado de Guanajuato | Sistema Interno de Usuarios
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
